import express from 'express'
import cors from 'cors'
import compression from 'compression'
import morgan from 'morgan'
import path from 'path'
import { fileURLToPath } from 'url'
import dotenv from 'dotenv'
dotenv.config()

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const app = express()
app.use(cors()); app.use(express.json()); app.use(compression()); app.use(morgan('dev'))
const PORT = process.env.PORT || 5000

app.get('/api/health', (req,res)=> res.json({ ok:true }))
app.get('/api/metrics/today', (req,res)=> res.json({ applied:3, optimized:2, found:25, agents:1 }))
app.get('/api/metrics/alltime', (req,res)=> res.json({ applied:87, optimized:64, found:412, agents:5 }))
app.post('/api/checkout/intent', (req,res)=> res.json({ clientSecret:'mock_secret', amount:3900, currency:'usd' }))
app.post('/api/checkout/complete', (req,res)=> res.json({ success:true }))

if (process.env.NODE_ENV === 'production') {
  const clientBuild = path.resolve(__dirname, '../client/build')
  app.use(express.static(clientBuild))
  app.get('*', (req,res)=> res.sendFile(path.join(clientBuild, 'index.html')))
} else {
  app.get('/', (req,res)=> res.send('Talendro™ server running.'))
}

app.listen(PORT, ()=> console.log(`Server on http://localhost:${PORT}`))
