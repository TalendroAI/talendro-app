import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'

function Header(){
  return (<header className="border-b border-gray-100">
    <div className="container flex items-center justify-between py-4">
      <Link to="/" className="font-mont font-bold text-xl text-talBlue">Talendro™</Link>
      <nav className="hidden md:flex items-center gap-6 font-mont">
        <Link to="/">Home</Link><Link to="/services">Services</Link><Link to="/pricing">Pricing</Link>
        <Link to="/about">About</Link><Link to="/resources/faq">FAQ</Link><Link to="/contact">Contact</Link>
      </nav>
      <Link to="/app/onboarding/welcome" className="btn btn-primary">Get Started</Link>
    </div>
  </header>)
}
function Footer(){ return (<footer className="mt-16 border-t border-gray-100"><p className="footerline">🇺🇸 American-Built   👨‍✈️ Veteran-Led   ✔ Recruiter-Tested</p><div className="pb-8"/></footer>) }

const Home = ()=> (<section><h1 className="h1">Talendro™</h1><p className="tagline mt-2">Precision Matches. Faster results.</p>
  <p className="mt-6">Your autonomous job search navigator. More roles. Better matches. Faster offers.</p>
  <div className="mt-6"><Link to="/app/onboarding/welcome" className="btn btn-primary">Start Your Job Search</Link> <Link to="/how-it-works" className="btn btn-secondary">Learn How It Works</Link></div>
</section>)

const Simple = ({title, body})=> (<section><h1 className="h1">{title}</h1><p className="mt-4">{body}</p></section>)

const How = ()=> <Simple title="How Talendro™ Works" body="Upload once. Complete essentials. Build agents. We tailor & time. You track results."/>
const Services = ()=> <Simple title="Services" body="Talendro™ Navigator (everything included) + Optional AI Add-Ons."/>
const Navigator = ()=> <Simple title="Talendro™ Navigator" body="Real-time discovery, AI résumé tailoring, smart scoring, one-click apply, alerts & tracking."/>
const Optional = ()=> <Simple title="Optional AI Add-Ons" body="Interview Coach, Transition & First 100 Days, Career Branding Suite, Concierge, Networking (Soon)."/>
const Pricing = ()=> <Simple title="Pricing" body="$39/month. One flat price. Full access. Zero hidden tiers."/>
const About = ()=> <Simple title="About Talendro™" body="We level the playing field for experienced professionals."/>
const Story = ()=> <Simple title="Our Story" body="Built by a veteran recruiting leader to deliver precision and speed."/>
const Team = ()=> <Simple title="Our Team" body="Led by K. Greg Jackson — 20+ years in recruitment leadership."/>
const FAQ = ()=> <Simple title="FAQ" body="Auto-apply vs review-first, what’s included, security, and more."/>
const Contact = ()=> <Simple title="Contact" body="support@talendro.com · partners@talendro.com · press@talendro.com"/>
const Veterans = ()=> <Simple title="Veterans" body="Free access for eligible veterans, priority onboarding, transition resources."/>
const Security = ()=> <Simple title="Security" body="Encryption, access controls, monitoring, privacy by design."/>
const Privacy = ()=> <Simple title="Privacy Policy" body="We collect the minimum to deliver the service and never sell your data."/>
const Terms = ()=> <Simple title="Terms of Service" body="Subscription, acceptable use, no employment guarantee, cancellations, liability."/>

const OnbWelcome = ()=> <Simple title="Welcome to Talendro™" body="Create your profile to unlock autonomous job search."/>
const OnbStep1 = ()=> <Simple title="Create Profile" body="First/Last, Email, Phone, Password (12+ chars)."/>
const OnbStep2 = ()=> <Simple title="Upload Résumé" body="Drag & drop PDF/DOCX — we’ll parse to pre-fill."/>
const OnbReview = ()=> <Simple title="Final Review" body="Confirm details, then Approve & Continue to Payment."/>
const Checkout = ()=> <Simple title="Payment & Checkout" body="Plan: $39/month. Enter payment details to complete."/>
const CheckoutSuccess = ()=> <Simple title="Success" body="Thanks! Go to Dashboard or build your first agent."/>
const Dashboard = ()=> <Simple title="Dashboard" body="Today vs All-Time metrics, recent activity, quick actions."/>

function App(){
  return (<>
    <Header />
    <main className="container py-10">
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/how-it-works" element={<How/>} />
        <Route path="/services" element={<Services/>} />
        <Route path="/services/navigator" element={<Navigator/>} />
        <Route path="/services/optional" element={<Optional/>} />
        <Route path="/pricing" element={<Pricing/>} />
        <Route path="/about" element={<About/>} />
        <Route path="/about/our-story" element={<Story/>} />
        <Route path="/about/our-team" element={<Team/>} />
        <Route path="/resources/faq" element={<FAQ/>} />
        <Route path="/contact" element={<Contact/>} />
        <Route path="/veterans" element={<Veterans/>} />
        <Route path="/security" element={<Security/>} />
        <Route path="/privacy" element={<Privacy/>} />
        <Route path="/terms" element={<Terms/>} />
        <Route path="/app/onboarding/welcome" element={<OnbWelcome/>} />
        <Route path="/app/onboarding/step-1" element={<OnbStep1/>} />
        <Route path="/app/onboarding/step-2" element={<OnbStep2/>} />
        <Route path="/app/onboarding/review" element={<OnbReview/>} />
        <Route path="/app/checkout" element={<Checkout/>} />
        <Route path="/app/checkout/success" element={<CheckoutSuccess/>} />
        <Route path="/app/dashboard" element={<Dashboard/>} />
      </Routes>
    </main>
    <Footer />
  </>)
}

const root = ReactDOM.createRoot(document.getElementById('root'))
root.render(<React.StrictMode><BrowserRouter><App/></BrowserRouter></React.StrictMode>)
