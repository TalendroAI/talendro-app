import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import Button from '../ui/Button'
export default function SignIn(){
  const nav = useNavigate()
  const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [error,setError]=useState('')
  const onSubmit=(e)=>{e.preventDefault(); if(!email||!password){setError('Please enter your email and password.');return;} nav('/app/dashboard')}
  return (<section><h1 className="h1">Sign In</h1><p className="body mt-2">Welcome back. Enter your credentials to access your dashboard.</p>
    <form onSubmit={onSubmit} className="card mt-6 max-w-lg">
      {error && <div className="mb-3 text-red-600 text-sm">{error}</div>}
      <label className="block body mb-2">Email</label>
      <input className="w-full border border-talGray rounded-xl h-11 px-3" value={email} onChange={e=>setEmail(e.target.value)} required />
      <label className="block body mt-4 mb-2">Password</label>
      <input type="password" className="w-full border border-talGray rounded-xl h-11 px-3" value={password} onChange={e=>setPassword(e.target.value)} required />
      <div className="mt-4 flex items-center justify-between">
        <Button type="submit">Sign In</Button>
        <Link to="/auth/forgot" className="btn btn-tertiary">Forgot Password?</Link>
      </div>
    </form></section>)
}
