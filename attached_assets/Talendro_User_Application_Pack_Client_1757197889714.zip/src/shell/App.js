import { Routes, Route } from 'react-router-dom'
import Header from '../ui/Header'
import SignIn from '../auth/SignIn'
import Onb3 from '../app/Onb3'; import Onb4 from '../app/Onb4'; import Onb5 from '../app/Onb5'; import Onb6 from '../app/Onb6'; import Onb7 from '../app/Onb7'; import OnbReview from '../app/OnbReview'
import Dashboard from '../app/Dashboard'
const Agents = ()=> <section><h1 className="h1">Search Agents</h1><p>List of agents and boolean strings.</p></section>
const Jobs = ()=> <section><h1 className="h1">Jobs</h1><p>Jobs feed from your agents.</p></section>
const Resumes = ()=> <section><h1 className="h1">Resumes</h1><p>Tailored resumes vault.</p></section>
const Applications = ()=> <section><h1 className="h1">Applications</h1><p>All applications submitted.</p></section>
export default function App(){return (<><Header /><main className="container py-10"><Routes>
  <Route path="/auth/sign-in" element={<SignIn />} />
  <Route path="/app/onboarding/step-3" element={<Onb3 />} />
  <Route path="/app/onboarding/step-4" element={<Onb4 />} />
  <Route path="/app/onboarding/step-5" element={<Onb5 />} />
  <Route path="/app/onboarding/step-6" element={<Onb6 />} />
  <Route path="/app/onboarding/step-7" element={<Onb7 />} />
  <Route path="/app/onboarding/review" element={<OnbReview />} />
  <Route path="/app/dashboard" element={<Dashboard />} />
  <Route path="/app/agents" element={<Agents />} />
  <Route path="/app/jobs" element={<Jobs />} />
  <Route path="/app/resumes" element={<Resumes />} />
  <Route path="/app/applications" element={<Applications />} />
</Routes></main></>)}
