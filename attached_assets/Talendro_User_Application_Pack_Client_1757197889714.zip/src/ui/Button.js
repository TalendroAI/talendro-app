export default function Button({ variant='primary', className='', children, ...props }){
  const variants = { primary:'btn btn-primary', secondary:'btn btn-secondary', tertiary:'btn btn-tertiary' }
  const v = variants[variant] || variants.primary
  return <button className={[v,className].filter(Boolean).join(' ')} {...props}>{children}</button>
}
