import { Link } from 'react-router-dom'
import Button from './Button'
export default function Header(){
  return (
    <header className="border-b border-gray-100">
      <div className="container flex items-center justify-between py-4">
        <Link to="/" className="font-mont font-bold text-xl text-talBlue">Talendro™</Link>
        <nav className="hidden md:flex items-center gap-6 font-mont">
          <Link to="/">Home</Link><Link to="/how-it-works">How It Works</Link><Link to="/services">Services</Link>
          <Link to="/pricing">Pricing</Link><Link to="/about">About</Link><Link to="/resources/faq">FAQ</Link><Link to="/contact">Contact</Link>
        </nav>
        <div className="hidden md:flex items-center gap-3">
          <Link to="/auth/sign-in" className="btn btn-secondary">Sign In</Link>
          <Link to="/app/onboarding/welcome"><Button>Get Started</Button></Link>
        </div>
      </div>
    </header>
  )
}
