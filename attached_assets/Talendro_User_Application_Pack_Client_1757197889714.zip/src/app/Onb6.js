import Button from '../ui/Button'
export default function Onb6(){
  return (<section><h1 className="h1">Employment History (Last 10 Years)</h1><p className="body mt-2">List roles in reverse chronological order.</p>
    <div className="card mt-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div><label className="block body mb-2">Company Name *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
        <div><label className="block body mb-2">Company Address (Street, City, State, Zip/Country) *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
        <div><label className="block body mb-2">Job Title *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
        <div><label className="block body mb-2">Dates Employed (MM/YYYY – MM/YYYY or “Present”) *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
        <div><label className="block body mb-2">Supervisor Name *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
        <div><label className="block body mb-2">Supervisor Title *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
        <div><label className="block body mb-2">OK to Contact Supervisor? * (Yes/No; “Contact after offer” option)</label>
          <select className="w-full border border-talGray rounded-xl h-11 px-3" required><option value="">Select</option><option>Yes</option><option>No</option><option>Contact after offer</option></select>
        </div>
        <div><label className="block body mb-2">Starting Salary (annual or hourly)</label><input className="w-full border border-talGray rounded-xl h-11 px-3" /></div>
        <div><label className="block body mb-2">Ending Salary (annual or hourly)</label><input className="w-full border border-talGray rounded-xl h-11 px-3" /></div>
        <div className="md:col-span-2"><label className="block body mb-2">Reason for Leaving * (enter “N/A — current” if still employed)</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
      </div>
      <div className="mt-4"><button className="btn btn-secondary">+ Add Another Role</button></div>
    </div>
    <div className="mt-6"><a href="/app/onboarding/step-7"><Button>Continue</Button></a></div>
  </section>)
}
