import Button from '../ui/Button'
export default function OnbReview(){
  return (<section><h1 className="h1">Final Review</h1><p className="body mt-2">Review your profile before Talendro™ goes to work.</p>
    <div className="grid md:grid-cols-2 gap-6 mt-6">
      <div className="card"><p className="text-talGray">Summary: Personal</p></div>
      <div className="card"><p className="text-talGray">Summary: Residential</p></div>
      <div className="card"><p className="text-talGray">Summary: Education</p></div>
      <div className="card"><p className="text-talGray">Summary: Employment</p></div>
      <div className="card md:col-span-2"><p className="text-talGray">Summary: Voluntary Self‑ID & Consent</p></div>
    </div>
    <div className="mt-6 flex gap-3">
      <a href="/app/checkout"><Button>Approve &amp; Continue to Payment</Button></a>
      <button className="btn btn-tertiary">Save &amp; Return Later</button>
    </div>
  </section>)
}
