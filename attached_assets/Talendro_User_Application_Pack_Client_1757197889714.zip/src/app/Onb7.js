import Button from '../ui/Button'
export default function Onb7(){
  return (<section><h1 className="h1">Voluntary Self‑Identification & Consent</h1><p className="body mt-2">Choose to complete or decline these optional disclosures. Talendro™ will mirror your choice on applications.</p>
    <h2 className="h2 mt-8 mb-3">Global Preference</h2>
    <div className="card"><label className="block body mb-2">How should Talendro™ handle these disclosures?</label>
      <select className="w-full border border-talGray rounded-xl h-11 px-3 max-w-xl"><option>Auto-complete using my selections</option><option>Always decline</option><option>Ask me each time</option></select>
    </div>
    <h2 className="h2 mt-8 mb-3">Voluntary EEO & Demographic</h2>
    <div className="card grid md:grid-cols-2 gap-6">
      <div><label className="block body mb-2">Ethnicity</label><select className="w-full border border-talGray rounded-xl h-11 px-3"><option>Prefer not to say</option><option>Hispanic or Latino</option><option>Not Hispanic or Latino</option></select></div>
      <div><label className="block body mb-2">Gender</label><select className="w-full border border-talGray rounded-xl h-11 px-3"><option>Prefer not to say</option><option>Female</option><option>Male</option><option>Non-binary</option><option>Other</option></select></div>
      <div className="md:col-span-2"><label className="block body mb-2">Race (multi-select)</label>
        <div className="flex flex-wrap gap-4">{["American Indian or Alaska Native","Asian","Black or African American","Native Hawaiian or Other Pacific Islander","White","Prefer not to say"].map(r=>(<label key={r}><input type="checkbox" className="mr-2" />{r}</label>))}</div>
      </div>
      <div className="md:col-span-2"><label className="block body mb-2">Sexual Orientation</label><select className="w-full border border-talGray rounded-xl h-11 px-3"><option>Prefer not to say</option><option>Heterosexual/Straight</option><option>Gay/Lesbian</option><option>Bisexual</option><option>Pansexual</option><option>Asexual</option><option>Queer</option><option>Other</option></select></div>
    </div>
    <h2 className="h2 mt-8 mb-3">Veteran Self‑Identification</h2>
    <div className="card grid md:grid-cols-2 gap-6">
      <div><label className="block body mb-2">Status</label><select className="w-full border border-talGray rounded-xl h-11 px-3"><option>Declines to self-identify</option><option>Not a protected veteran</option><option>Protected veteran</option></select></div>
      <div><label className="block body mb-2">Protected Veteran Type(s)</label><div className="flex flex-wrap gap-4">{["Disabled Veteran","Active-Duty Wartime or Campaign Badge Veteran","Armed Forces Service Medal Veteran","Recently Separated Veteran"].map(t=>(<label key={t}><input type="checkbox" className="mr-2" />{t}</label>))}</div></div>
      <div><label className="block body mb-2">If Recently Separated: Discharge Date (MM/DD/YYYY)</label><input className="w-full border border-talGray rounded-xl h-11 px-3" placeholder="MM/DD/YYYY" /></div>
    </div>
    <h2 className="h2 mt-8 mb-3">Voluntary Self‑ID of Disability (CC‑305)</h2>
    <div className="card"><label className="block body mb-2">Do you have a disability?</label><select className="w-full border border-talGray rounded-xl h-11 px-3 max-w-xl"><option>I do not want to answer</option><option>Yes, I have a disability (or have had one)</option><option>No, I do not have a disability</option></select><p className="text-sm text-talGray mt-3">We store your preference and mirror it on employer forms that ask.</p></div>
    <h2 className="h2 mt-8 mb-3">Standing Consent</h2>
    <div className="card">
      <label className="inline-flex items-center"><input type="checkbox" className="mr-2" /> I authorize Talendro™ to apply on my behalf using the information I’ve provided.</label>
      <div className="grid md:grid-cols-2 gap-6 mt-4">
        <div><label className="block body mb-2">Typed Legal Name *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
        <div><label className="block body mb-2">Date *</label><input type="date" className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
      </div>
    </div>
    <div className="mt-6"><a href="/app/onboarding/review" className="btn btn-primary">Continue</a></div>
  </section>)
}
