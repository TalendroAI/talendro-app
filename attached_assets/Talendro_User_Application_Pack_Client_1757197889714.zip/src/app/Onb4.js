import Button from '../ui/Button'
export default function Onb4(){
  return (<section><h1 className="h1">Residential History (Last 7 Years)</h1><p className="body mt-2">Add residences starting with your current address.</p>
    <div className="card mt-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div><label className="block body mb-2">Street Address *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
        <div><label className="block body mb-2">City, State, Zip *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
        <div><label className="block body mb-2">County *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
        <div><label className="block body mb-2">Country *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
        <div><label className="block body mb-2">Dates of Residency (From MM/YYYY – To MM/YYYY) *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
      </div>
      <div className="mt-4"><button className="btn btn-secondary">+ Add Another Address</button></div>
    </div>
    <div className="mt-6"><a href="/app/onboarding/step-5"><button className="btn btn-primary">Continue</button></a></div>
  </section>)
}
