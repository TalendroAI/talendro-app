import Button from '../ui/Button'
export default function Onb5(){
  return (<section><h1 className="h1">Educational History</h1><p className="body mt-2">List education in reverse chronological order.</p>
    <div className="card mt-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div><label className="block body mb-2">Institution Name *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
        <div><label className="block body mb-2">Location (City, State/Country) *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
        <div><label className="block body mb-2">Dates Attended (MM/YYYY – MM/YYYY) *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
        <div><label className="block body mb-2">Degree (e.g., BS/BA/MS/etc.) *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
        <div><label className="block body mb-2">Major / Field of Study *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
        <div><label className="block body mb-2">GPA / Honors (optional)</label><input className="w-full border border-talGray rounded-xl h-11 px-3" /></div>
      </div>
      <div className="mt-4"><button className="btn btn-secondary">+ Add Another Education</button></div>
    </div>
    <div className="mt-6"><a href="/app/onboarding/step-6"><Button>Continue</Button></a></div>
  </section>)
}
