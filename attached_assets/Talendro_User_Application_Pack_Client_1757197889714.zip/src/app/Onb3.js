import Button from '../ui/Button'
export default function Onb3(){
  return (<section><h1 className="h1">Personal Information</h1>
    <h2 className="h2 mt-6 mb-3">A) Name & Contact</h2>
    <div className="card grid md:grid-cols-2 gap-6">
      <div>
        <label className="block body mb-2">Full Legal Name *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required />
        <label className="block body mt-4 mb-2">Full Maiden Name * (N/A if not applicable)</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required placeholder="N/A if not applicable" />
        <label className="block body mt-4 mb-2">Nickname (if any)</label><input className="w-full border border-talGray rounded-xl h-11 px-3" />
      </div>
      <div>
        <label className="block body mb-2">Email Address *</label><input type="email" className="w-full border border-talGray rounded-xl h-11 px-3" required />
        <label className="block body mt-4 mb-2">Phone Number *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required />
        <label className="block body mt-4 mb-2">Physical Address * (street, city, state, zip, county, country)</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required placeholder="123 Main St, City, ST, 12345, County, USA" />
      </div>
      <div>
        <label className="block body mt-4 mb-2">Date of Birth * (only provided to employer if required by an application)</label><input type="date" className="w-full border border-talGray rounded-xl h-11 px-3" required />
      </div>
      <div>
        <label className="block body mt-4 mb-2">SSN (last 4) * (only provided to employer if required by an application)</label><input className="w-full border border-talGray rounded-xl h-11 px-3" maxLength="4" required />
      </div>
    </div>
    <h2 className="h2 mt-10 mb-3">B) Emergency Contact</h2>
    <div className="card grid md:grid-cols-3 gap-6">
      <div><label className="block body mb-2">Name *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
      <div><label className="block body mb-2">Relationship *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
      <div><label className="block body mb-2">Phone Number *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
    </div>
    <h2 className="h2 mt-10 mb-3">C) Availability & Preferences</h2>
    <div className="card grid md:grid-cols-2 gap-6">
      <div><label className="block body mb-2">Desired Salary / Hourly Rate *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
      <div><label className="block body mb-2">Available Start Date *</label><input type="date" className="w-full border border-talGray rounded-xl h-11 px-3" required /></div>
      <div><label className="block body mb-2">Open to Relocation? *</label><select className="w-full border border-talGray rounded-xl h-11 px-3" required><option value="">Select</option><option>Yes</option><option>No</option></select></div>
      <div>
        <label className="block body mb-2">Willing to Travel? *</label><select className="w-full border border-talGray rounded-xl h-11 px-3" required><option value="">Select</option><option>Yes</option><option>No</option></select>
        <label className="block body mt-4 mb-2">Acceptable Travel % *</label><input className="w-full border border-talGray rounded-xl h-11 px-3" required />
      </div>
      <div><label className="block body mb-2">Able to work weekends/evenings/overtime if applicable? *</label><select className="w-full border border-talGray rounded-xl h-11 px-3" required><option value="">Select</option><option>Yes</option><option>No</option></select></div>
      <div className="md:col-span-2">
        <label className="block body mb-2">Are you currently subject to any non-compete, non-solicitation, or confidentiality agreement with a former employer that could impact your ability to perform the duties of this position? * (If yes, please explain)</label>
        <textarea className="w-full border border-talGray rounded-xl px-3 py-3" required placeholder="If yes, please explain"></textarea>
      </div>
    </div>
    <h2 className="h2 mt-10 mb-3">D) Work Arrangement</h2>
    <div className="card"><div className="flex gap-6 flex-wrap"><label><input type="checkbox" className="mr-2" />Onsite</label><label><input type="checkbox" className="mr-2" />Remote</label><label><input type="checkbox" className="mr-2" />Hybrid</label></div></div>
    <h2 className="h2 mt-10 mb-3">E) Work Eligibility (U.S. or relevant country)</h2>
    <div className="card grid md:grid-cols-2 gap-6">
      <div><label className="block body mb-2">Are you a United States Citizen, Permanent Resident, or Refugee or Asylee? *</label><select className="w-full border border-talGray rounded-xl h-11 px-3" required><option value="">Select</option><option>Yes</option><option>No</option></select></div>
      <div><label className="block body mb-2">Are you legally authorized to work for any employer in the United States? *</label><select className="w-full border border-talGray rounded-xl h-11 px-3" required><option value="">Select</option><option>Yes</option><option>No</option></select></div>
      <div className="md:col-span-2"><label className="block body mb-2">Will you now or in the future require visa sponsorship for continued employment? *</label><select className="w-full border border-talGray rounded-xl h-11 px-3" required><option value="">Select</option><option>Yes</option><option>No</option></select></div>
    </div>
    <h2 className="h2 mt-10 mb-3">F) Criminal History</h2>
    <div className="card">
      <label className="block body mb-2">Have you ever been convicted of a misdemeanor or felony (excluding minor traffic violations) that has not been expunged, sealed, or legally dismissed? *</label>
      <select className="w-full border border-talGray rounded-xl h-11 px-3 max-w-md" required><option value="">Select</option><option>Yes</option><option>No</option></select>
      <label className="block body mt-4 mb-2">If Yes: Details</label><textarea className="w-full border border-talGray rounded-xl px-3 py-3" placeholder="Nature of offense, date, sentence, notes"></textarea>
    </div>
    <div className="mt-6"><a href="/app/onboarding/step-4"><Button>Continue</Button></a></div>
  </section>)
}
