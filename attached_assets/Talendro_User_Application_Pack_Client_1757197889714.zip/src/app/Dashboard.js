import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
export default function Dashboard(){
  const [today,setToday]=useState({applied:0,optimized:0,found:0,agents:0})
  const [all,setAll]=useState({applied:0,optimized:0,found:0,agents:0})
  useEffect(()=>{fetch('/api/metrics/today').then(r=>r.json()).then(setToday).catch(()=>{});fetch('/api/metrics/alltime').then(r=>r.json()).then(setAll).catch(()=>{})},[])
  return (<section><h1 className="h1">Welcome back!</h1><p className="body mt-2">Your autonomous job search is running. Here’s how you’re doing.</p>
    <h2 className="h2 mt-8 mb-3">Today’s Progress</h2>
    <div className="grid md:grid-cols-4 gap-4">
      <Link to="/app/applications" className="metric metric-today block"><div className="text-3xl font-bold">{today.applied}</div><div>Jobs Applied Today</div></Link>
      <Link to="/app/resumes" className="metric metric-today block"><div className="text-3xl font-bold">{today.optimized}</div><div>Resumes Optimized Today</div></Link>
      <Link to="/app/jobs" className="metric metric-today block"><div className="text-3xl font-bold">{today.found}</div><div>Jobs Found Today</div></Link>
      <Link to="/app/agents" className="metric metric-today block"><div className="text-3xl font-bold">{today.agents}</div><div>Search Agents Built Today</div></Link>
    </div>
    <h2 className="h2 mt-10 mb-3">All-Time Performance</h2>
    <div className="grid md:grid-cols-4 gap-4">
      <Link to="/app/applications" className="metric metric-all block"><div className="text-3xl font-bold">{all.applied}</div><div>Total Jobs Applied</div></Link>
      <Link to="/app/resumes" className="metric metric-all block"><div className="text-3xl font-bold">{all.optimized}</div><div>Total Resumes Optimized</div></Link>
      <Link to="/app/jobs" className="metric metric-all block"><div className="text-3xl font-bold">{all.found}</div><div>Total Jobs Found</div></Link>
      <Link to="/app/agents" className="metric metric-all block"><div className="text-3xl font-bold">{all.agents}</div><div>Total Search Agents Built</div></Link>
    </div>
    <h2 className="h2 mt-10 mb-3">Quick Links</h2>
    <div className="card"><ul className="text-sm text-talSlate space-y-2">
      <li>📄 <a className="underline" href="/api/user/files/resume" target="_blank" rel="noreferrer">Original Uploaded Résumé</a></li>
      <li>📝 <a className="underline" href="/api/user/files/application" target="_blank" rel="noreferrer">Originally Completed Application (Compiled)</a></li>
    </ul></div>
  </section>)
}
