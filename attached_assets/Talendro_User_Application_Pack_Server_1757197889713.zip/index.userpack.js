import express from 'express'
import cors from 'cors'
import compression from 'compression'
import morgan from 'morgan'
import userRoutes from './routes.user.js'

const app = express()
app.use(cors()); app.use(express.json()); app.use(compression()); app.use(morgan('dev'))
const PORT = process.env.PORT || 5000

// Metrics used by Dashboard (mock)
app.get('/api/metrics/today', (req,res)=> res.json({ applied:3, optimized:2, found:25, agents:1 }))
app.get('/api/metrics/alltime', (req,res)=> res.json({ applied:87, optimized:64, found:412, agents:5 }))

// User/app routes
app.use('/api/user', userRoutes)

app.get('/api/health', (req,res)=> res.json({ ok:true }))

app.listen(PORT, ()=> console.log(`User pack server sample on http://localhost:${PORT}`))
