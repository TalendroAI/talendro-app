import { Router } from 'express'
const r = Router()

r.get('/agents', (req,res)=>{
  res.json([
    { id: 1, name: 'Sr Project Manager — Atlanta', boolean: '("project manager" OR "program manager") AND (PMP OR Agile) AND (Atlanta OR GA)' },
    { id: 2, name: 'Operations Director — Remote', boolean: '("operations director" OR "director of operations") AND (SaaS OR healthcare)' }
  ])
})

r.get('/jobs', (req,res)=>{
  res.json({
    week: [{ id: 101, title: 'Senior Analyst', company: 'GlobalTech', posted: '2025-09-02' }],
    all: [{ id: 55, title: 'Project Manager', company: 'Acme', posted: '2025-08-15' }, { id: 56, title: 'Ops Lead', company: 'NorthStar', posted: '2025-08-20' }]
  })
})

r.get('/resumes', (req,res)=>{
  res.json({
    week: [{ id: 'r-2025-09-03', role: 'Senior Analyst', company: 'GlobalTech' }],
    all: [{ id: 'r-2025-08-20', role: 'Project Manager', company: 'Acme' }]
  })
})

r.get('/applications', (req,res)=>{
  res.json({
    week: [{ id: 'a-2025-09-03', role: 'Senior Analyst', company: 'GlobalTech', status: 'Submitted' }],
    all: [{ id: 'a-2025-08-20', role: 'Project Manager', company: 'Acme', status: 'In Review' }]
  })
})

r.get('/files/resume', (req,res)=>{
  res.setHeader('Content-Type','text/plain')
  res.send('This would stream the original uploaded resume file. Replace with your storage handler.')
})
r.get('/files/application', (req,res)=>{
  res.setHeader('Content-Type','text/plain')
  res.send('This would stream the compiled application PDF. Replace with your storage handler.')
})

export default r
