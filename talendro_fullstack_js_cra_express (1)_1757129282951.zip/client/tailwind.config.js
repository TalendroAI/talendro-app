/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        talBlue: "#2F6DF6",
        talSlate: "#2C2F38",
        talAqua: "#00C4CC",
        talLime: "#A4F400",
        talGray: "#9FA6B2",
        talWhite: "#FFFFFF"
      },
      fontFamily: {
        mont: ["Montserrat", "ui-sans-serif", "system-ui"],
        inter: ["Inter", "ui-sans-serif", "system-ui"],
        dmserif: ["DM Serif Display", "serif"]
      },
      borderRadius: {
        xl: "1rem",
        "2xl": "1.25rem"
      },
      boxShadow: {
        card: "0 6px 20px rgba(0,0,0,0.06)"
      }
    }
  },
  plugins: []
}
