export default function TrustBadge(){ return <p className='footerline'>🇺🇸 American-Built   👨‍✈️ Veteran-Led   ✔ Recruiter-Tested</p> }
