import { Link } from 'react-router-dom'
import TrustBadge from './TrustBadge'

export default function Footer(){
  return (
    <footer className="mt-16 border-t border-gray-100">
      <div className="container py-10 grid gap-4 md:grid-cols-2 text-sm">
        <div className="space-y-2">
          <p className="font-mont font-bold text-talBlue">Talendro™</p>
          <p className="text-talGray">Precision Matches. Faster Results.</p>
          <div className="flex gap-3 text-talGray flex-wrap">
            <Link to="/veterans">Veterans Program</Link>
            <Link to="/security">Security</Link>
            <Link to="/privacy">Privacy</Link>
            <Link to="/terms">Terms</Link>
          </div>
        </div>
        <div className="space-y-2 md:justify-self-end">
          <div className="flex gap-3 text-talGray flex-wrap">
            <Link to="/">Home</Link>
            <Link to="/how-it-works">How It Works</Link>
            <Link to="/services">Services</Link>
            <Link to="/pricing">Pricing</Link>
            <Link to="/about">About</Link>
            <Link to="/resources/faq">FAQ</Link>
            <Link to="/contact">Contact</Link>
          </div>
        </div>
      </div>
      <TrustBadge />
      <div className="pb-8" />
    </footer>
  )
}
