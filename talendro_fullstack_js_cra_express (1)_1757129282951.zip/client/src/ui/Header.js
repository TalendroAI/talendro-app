import { Link } from 'react-router-dom'
import { useState } from 'react'
import Button from './Button'

export default function Header(){
  const [open, setOpen] = useState(false)
  return (
    <header className="border-b border-gray-100">
      <div className="container flex items-center justify-between py-4">
        <Link to="/" className="font-mont font-bold text-xl text-talBlue">Talendro™</Link>
        <nav className="hidden md:flex items-center gap-6 font-mont">
          <Link to="/">Home</Link>
          <Link to="/how-it-works">How It Works</Link>
          <div className="group relative">
            <button className="inline-flex items-center gap-1">Services ▾</button>
            <div className="absolute invisible group-hover:visible opacity-0 group-hover:opacity-100 transition bg-white shadow-card rounded-xl p-3 top-full left-0 w-64">
              <Link className="block px-3 py-2 rounded-lg hover:bg-gray-50" to="/services/navigator">Talendro™ Navigator</Link>
              <Link className="block px-3 py-2 rounded-lg hover:bg-gray-50" to="/services/optional">Optional AI Services</Link>
            </div>
          </div>
          <Link to="/pricing">Pricing</Link>
          <div className="group relative">
            <button className="inline-flex items-center gap-1">About ▾</button>
            <div className="absolute invisible group-hover:visible opacity-0 group-hover:opacity-100 transition bg-white shadow-card rounded-xl p-3 top-full left-0 w-56">
              <Link className="block px-3 py-2 rounded-lg hover:bg-gray-50" to="/about/our-story">Our Story</Link>
              <Link className="block px-3 py-2 rounded-lg hover:bg-gray-50" to="/about/our-team">Our Team</Link>
            </div>
          </div>
          <div className="group relative">
            <button className="inline-flex items-center gap-1">Resources ▾</button>
            <div className="absolute invisible group-hover:visible opacity-0 group-hover:opacity-100 transition bg-white shadow-card rounded-xl p-3 top-full left-0 w-56">
              <Link className="block px-3 py-2 rounded-lg hover:bg-gray-50" to="/resources/faq">FAQ</Link>
              <span className="block px-3 py-2 text-talGray">Blog (future)</span>
            </div>
          </div>
          <Link to="/contact">Contact</Link>
        </nav>
        <div className="hidden md:block">
          <Link to="/app/onboarding/welcome"><Button>Get Started</Button></Link>
        </div>
        <button className="md:hidden" onClick={()=>setOpen(!open)} aria-label="Open Menu">☰</button>
      </div>
      {open && (
        <div className="md:hidden border-t border-gray-100">
          <div className="container py-4 flex flex-col gap-3">
            <Link to="/">Home</Link>
            <Link to="/how-it-works">How It Works</Link>
            <span className="font-semibold">Services</span>
            <div className="pl-3 flex flex-col gap-2">
              <Link to="/services/navigator">Talendro™ Navigator</Link>
              <Link to="/services/optional">Optional AI Services</Link>
            </div>
            <Link to="/pricing">Pricing</Link>
            <span className="font-semibold">About</span>
            <div className="pl-3 flex flex-col gap-2">
              <Link to="/about/our-story">Our Story</Link>
              <Link to="/about/our-team">Our Team</Link>
            </div>
            <span className="font-semibold">Resources</span>
            <div className="pl-3 flex flex-col gap-2">
              <Link to="/resources/faq">FAQ</Link>
              <span className="text-talGray">Blog (future)</span>
            </div>
            <Link to="/contact">Contact</Link>
            <Link to="/app/onboarding/welcome"><Button className="mt-2">Get Started</Button></Link>
          </div>
        </div>
      )}
    </header>
  )
}
