export default function Page(){
  return (
    <section>
      <h1 className="h1">Talendro™ Navigator</h1>
      
      <div className="mt-6"><p className='body mb-4'>Everything included. One flat price. Full access. Zero hidden tiers.</p>
<p className='body mb-4'>Real-time job discovery · AI-powered résumé tailoring · Smart match scoring · One-click applications · Personalized alerts & tracking.</p></div>
      <div className='mt-6 flex flex-wrap gap-3'><a href='/app/onboarding/welcome'><button className='btn btn-primary mr-3'>Get Started Now</button></a></div>
    </section>
  )
}
