export default function Page(){
  return (
    <section>
      <h1 className="h1">Pricing</h1>
      <p className='tagline mt-2'>Precision Matches. Faster Results.</p>
      <div className="mt-6"><p className='body mb-4'>$39/month — One flat price. Full access. Zero hidden tiers.</p>
<p className='body mb-4'>Included: Real-time job discovery · AI résumé tailoring · Smart match scoring · One-click applications · Personalized alerts & tracking.</p>
<p className='body mb-4'>Cancel anytime. No hidden tiers. Full transparency.</p></div>
      <div className='mt-6 flex flex-wrap gap-3'><a href='/app/onboarding/welcome'><button className='btn btn-primary mr-3'>Start Your Journey Today</button></a></div>
    </section>
  )
}
