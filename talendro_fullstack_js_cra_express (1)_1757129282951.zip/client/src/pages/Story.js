export default function Page(){
  return (
    <section>
      <h1 className="h1">Our Story</h1>
      
      <div className="mt-6"><p className='body mb-4'>Because great experience deserves great opportunities.</p>
<p className='body mb-4'>The job search is stacked against experienced professionals. Talendro™ flips the script with real-time discovery, tailored résumés, and perfectly timed applications.</p>
<p className='body mb-4'>Founded by K. Greg Jackson, veteran recruiter and AI Blackbelt.</p></div>
      <div className='mt-6 flex flex-wrap gap-3'><a href='/services/navigator'><button className='btn btn-primary mr-3'>Try Talendro™ Navigator</button></a></div>
    </section>
  )
}
