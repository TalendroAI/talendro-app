export default function Page(){
  return (
    <section>
      <h1 className="h1">Our Team</h1>
      
      <div className="mt-6"><p className='body mb-4'>Empathy meets expertise.</p>
<p className='body mb-4'>K. Greg Jackson — Founder & CEO. 20+ years in recruitment leadership (IBM, American Airlines, Cox, HealthTrust). Pioneered AI hiring at IBM. AI Blackbelt.</p></div>
      <div className='mt-6 flex flex-wrap gap-3'><a href='/contact'><button className='btn btn-primary mr-3'>Join Us</button></a></div>
    </section>
  )
}
