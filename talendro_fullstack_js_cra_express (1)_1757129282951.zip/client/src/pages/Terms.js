export default function Page(){
  return (
    <section>
      <h1 className="h1">Terms of Service</h1>
      
      <div className="mt-6"><p className='body mb-4'>Simple, transparent terms.</p>
<p className='body mb-4'>Subscription & billing · Acceptable use · No guarantees of employment · Cancellation & refunds · Limitation of liability.</p></div>
      <div className='mt-6 flex flex-wrap gap-3'><a href='/pricing'><button className='btn btn-secondary mr-3'>View Pricing</button></a></div>
    </section>
  )
}
