export default function Page(){
  return (
    <section>
      <h1 className="h1">Contact Talendro™</h1>
      
      <div className="mt-6"><p className='body mb-4'>Support: support@talendro.com · Partnerships: partners@talendro.com · Media: press@talendro.com</p></div>
      <div className='mt-6 flex flex-wrap gap-3'><a href='/contact'><button className='btn btn-primary mr-3'>Send Message</button></a></div>
    </section>
  )
}
