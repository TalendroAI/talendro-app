export default function Page(){
  return (
    <section>
      <h1 className="h1">Privacy Policy</h1>
      
      <div className="mt-6"><p className='body mb-4'>We respect your privacy and protect your data.</p>
<p className='body mb-4'>We collect profile, document, application, and usage data to automate and optimize your job search. We never sell your data.</p></div>
      <div className='mt-6 flex flex-wrap gap-3'><a href='/contact'><button className='btn btn-secondary mr-3'>Questions? Contact Privacy</button></a></div>
    </section>
  )
}
