export default function Page(){
  return (
    <section>
      <h1 className="h1">About Talendro™</h1>
      <p className='tagline mt-2'>Precision Matches. Faster Results.</p>
      <div className="mt-6"><p className='body mb-4'>We exist to level the playing field for experienced professionals.</p></div>
      <div className='mt-6 flex flex-wrap gap-3'><a href='/about/our-story'><button className='btn btn-primary mr-3'>Read Our Story</button></a><a href='/about/our-team'><button className='btn btn-secondary mr-3'>Meet the Team</button></a></div>
    </section>
  )
}
