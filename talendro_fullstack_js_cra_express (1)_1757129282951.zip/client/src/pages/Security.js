export default function Page(){
  return (
    <section>
      <h1 className="h1">Security at Talendro™</h1>
      
      <div className="mt-6"><p className='body mb-4'>Your data is safe, encrypted, and private.</p>
<p className='body mb-4'>Encryption in transit & at rest · Secure cloud · Access controls · Monitoring · Privacy by design · Responsible AI.</p></div>
      <div className='mt-6 flex flex-wrap gap-3'><a href='/privacy'><button className='btn btn-secondary mr-3'>Read Privacy Policy</button></a></div>
    </section>
  )
}
