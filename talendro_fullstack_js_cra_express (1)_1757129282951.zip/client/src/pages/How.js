export default function Page(){
  return (
    <section>
      <h1 className="h1">How Talendro™ Works</h1>
      
      <div className="mt-6"><p className='body mb-4'>From job posting to application—fast, accurate, automatic.</p>
<p className='body mb-4'>1) Upload your résumé • 2) Complete essentials once • 3) Build search agents • 4) Tailor & time • 5) Track & improve.</p></div>
      <div className='mt-6 flex flex-wrap gap-3'><a href='/app/onboarding/welcome'><button className='btn btn-primary mr-3'>Get Started</button></a></div>
    </section>
  )
}
