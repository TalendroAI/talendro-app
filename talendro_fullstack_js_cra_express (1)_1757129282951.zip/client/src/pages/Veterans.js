export default function Page(){
  return (
    <section>
      <h1 className="h1">Veterans at Talendro™</h1>
      
      <div className="mt-6"><p className='body mb-4'>Our pledge: 10,000 veterans hired in 3 years.</p>
<p className='body mb-4'>Free Navigator access · Priority onboarding · Transition resources.</p></div>
      <div className='mt-6 flex flex-wrap gap-3'><a href='/app/onboarding/welcome?veteran=true'><button className='btn btn-primary mr-3'>Enroll as a Veteran</button></a></div>
    </section>
  )
}
