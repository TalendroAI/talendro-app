export default function Page(){
  return (
    <section>
      <h1 className="h1">FAQ</h1>
      
      <div className="mt-6"><p className='body mb-4'>Who is Talendro™ for? Mid-to-late career professionals and veterans.</p>
<p className='body mb-4'>How does Talendro™ find jobs? Always-on AI search agents monitor roles in real time.</p>
<p className='body mb-4'>Will Talendro™ apply for me? Yes—after your profile is complete. Auto-apply or approve-then-apply.</p>
<p className='body mb-4'>What does it cost? $39/month. Cancel anytime.</p></div>
      <div className='mt-6 flex flex-wrap gap-3'><a href='/contact'><button className='btn btn-secondary mr-3'>Contact Support</button></a></div>
    </section>
  )
}
