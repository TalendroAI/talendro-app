export default function Page(){
  return (
    <section>
      <h1 className="h1">Talendro™</h1>
      <p className='tagline mt-2'>Precision Matches. Faster Results.</p>
      <div className="mt-6"><p className='body mb-4'>Your autonomous job search navigator for experienced professionals.</p>
<p className='body mb-4'>More roles. Better matches. Faster offers.</p></div>
      <div className='mt-6 flex flex-wrap gap-3'><a href='/app/onboarding/welcome'><button className='btn btn-primary mr-3'>Start Your Job Search</button></a><a href='/how-it-works'><button className='btn btn-secondary mr-3'>Learn How It Works</button></a></div>
    </section>
  )
}
