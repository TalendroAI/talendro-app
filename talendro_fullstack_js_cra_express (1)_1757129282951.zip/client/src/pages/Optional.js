export default function Page(){
  return (
    <section>
      <h1 className="h1">Optional AI Add-Ons</h1>
      
      <div className="mt-6"><p className='body mb-4'>Mix and match—use one or many.</p>
<p className='body mb-4'>AI Interview Coach · AI Transition & First 100 Days Planner · AI Career Branding Suite · AI Career Concierge · Networking Insights (Coming Soon).</p></div>
      <div className='mt-6 flex flex-wrap gap-3'><a href='/app/billing'><button className='btn btn-primary mr-3'>Add to My Plan</button></a><a href='/services/optional'><button className='btn btn-secondary mr-3'>Learn More</button></a></div>
    </section>
  )
}
