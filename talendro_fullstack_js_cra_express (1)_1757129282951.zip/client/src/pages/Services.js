export default function Page(){
  return (
    <section>
      <h1 className="h1">Services</h1>
      <p className='tagline mt-2'>Precision Matches. Faster Results.</p>
      <div className="mt-6"><p className='body mb-4'>Two paths. One mission: get you hired faster.</p>
<p className='body mb-4'>Talendro™ Navigator — all-in-one plan.</p>
<p className='body mb-4'>Optional AI Services — add targeted tools when you want extra lift.</p></div>
      <div className='mt-6 flex flex-wrap gap-3'><a href='/services/navigator'><button className='btn btn-primary mr-3'>Explore Talendro™ Navigator</button></a><a href='/services/optional'><button className='btn btn-secondary mr-3'>Explore Optional Services</button></a></div>
    </section>
  )
}
