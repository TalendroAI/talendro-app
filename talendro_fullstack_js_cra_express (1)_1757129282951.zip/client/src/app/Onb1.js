export default function Page(){
  return (
    <section>
      <h1 className="h1">Create Profile</h1>
      <p className="tagline mt-2">Precision Matches. Faster Results.</p>
      <div className="grid md:grid-cols-2 gap-6 mt-6">
        <div className="card">
          <label className="block body mb-2">First Name *</label>
          <input className="w-full border border-talGray rounded-xl h-11 px-3 focus:outline-none focus:ring-2 focus:ring-talAqua" placeholder="John" />
          <label className="block body mt-4 mb-2">Last Name *</label>
          <input className="w-full border border-talGray rounded-xl h-11 px-3" placeholder="Doe" />
          <label className="block body mt-4 mb-2">Email *</label>
          <input className="w-full border border-talGray rounded-xl h-11 px-3" placeholder="john.doe@example.com" />
          <p className="text-sm text-talGray mt-2">Used for notifications and as your login.</p>
        </div>
        <div className="card">
          <label className="block body mb-2">Phone *</label>
          <input className="w-full border border-talGray rounded-xl h-11 px-3" placeholder="+1 (555) 123-4567" />
          <label className="block body mt-4 mb-2">Password *</label>
          <input type="password" className="w-full border border-talGray rounded-xl h-11 px-3" placeholder="••••••••" />
          <label className="block body mt-4 mb-2">Confirm Password *</label>
          <input type="password" className="w-full border border-talGray rounded-xl h-11 px-3" placeholder="••••••••" />
          <ul className="text-sm text-talGray mt-3 list-disc pl-5">
            <li>12+ characters</li>
            <li>Upper & lower case, number, special character</li>
            <li>No personal info</li>
          </ul>
        </div>
      </div>
      <div className="mt-6 flex gap-3">
        <a href="/app/onboarding/step-2"><button className="btn btn-primary">Create Profile &amp; Continue</button></a>
      </div>
      <p className="text-sm text-talGray mt-4">Your information is encrypted and never shared with third parties.</p>
    </section>
  )
}
