export default function Page(){
  return (
    <section>
      <h1 className="h1">Upload Résumé</h1>
      <p className="body mt-2">We’ll parse your résumé to pre-fill your profile.</p>
      <div className="card mt-6">
        <div className="border-2 border-dashed rounded-2xl p-10 text-center">
          <p>Drag & drop PDF/DOCX here, or</p>
          <button className="btn btn-secondary mt-3">Choose File</button>
        </div>
      </div>
      <div className="mt-6">
        <a href="/app/onboarding/step-3"><button className="btn btn-primary">Continue</button></a>
      </div>
    </section>
  )
}
