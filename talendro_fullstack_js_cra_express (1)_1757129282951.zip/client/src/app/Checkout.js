export default function Page(){
  return (
    <section>
      <h1 className="h1">Payment & Checkout</h1>
      <div className="grid md:grid-cols-3 gap-6 mt-6">
        <div className="md:col-span-2 card">
          <h3 className="h3 mb-4">Payment Details</h3>
          <label className="block body mb-2">Name on Card</label>
          <input className="w-full border border-talGray rounded-xl h-11 px-3" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <div>
              <label className="block body mb-2">Card Number</label>
              <input className="w-full border border-talGray rounded-xl h-11 px-3" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block body mb-2">Expiration (MM/YY)</label>
                <input className="w-full border border-talGray rounded-xl h-11 px-3" />
              </div>
              <div>
                <label className="block body mb-2">CVC</label>
                <input className="w-full border border-talGray rounded-xl h-11 px-3" />
              </div>
            </div>
          </div>
          <label className="block body mt-4 mb-2">Billing Address</label>
          <input className="w-full border border-talGray rounded-xl h-11 px-3" />
          <div className="mt-6">
            <a href="/app/checkout/success"><button className="btn btn-primary">Complete Purchase</button></a>
          </div>
          <p className="text-sm text-talGray mt-3">By completing purchase you agree to the Terms of Service and Privacy Policy.</p>
        </div>
        <div className="card">
          <h3 className="h3 mb-2">Plan Summary</h3>
          <p>Talendro™ Navigator — <strong>$39/month</strong></p>
          <h3 className="h3 mt-6 mb-2">Optional Add-Ons</h3>
          <ul className="list-disc pl-5 text-sm text-talSlate space-y-1">
            <li>AI Interview Coach</li>
            <li>AI Transition & First 100 Days Planner</li>
            <li>AI Career Branding Suite</li>
            <li>AI Career Concierge</li>
            <li className="text-talGray">Networking Insights (Coming Soon)</li>
          </ul>
          <label className="block body mt-6 mb-1">Promo Code</label>
          <input className="w-full border border-talGray rounded-xl h-11 px-3" placeholder="ENTER-CODE" />
          <p className="text-sm text-talGray mt-4">🔒 Secured via PCI-compliant processor. Encrypted in transit and at rest.</p>
        </div>
      </div>
    </section>
  )
}
