export default function Page(){
  return (
    <section>
      <h1 className="h1">Welcome back, [First Name]!</h1>
      <p className="body mt-2">Your autonomous job search is running. Here’s how you’re doing.</p>

      <h2 className="h2 mt-8 mb-3">Today’s Progress</h2>
      <div className="grid md:grid-cols-4 gap-4">
        <div className="metric metric-today"><div className="text-3xl font-bold">3</div><div>Jobs Applied Today</div></div>
        <div className="metric metric-today"><div className="text-3xl font-bold">2</div><div>Resumes Optimized Today</div></div>
        <div className="metric metric-today"><div className="text-3xl font-bold">25</div><div>Jobs Found Today</div></div>
        <div className="metric metric-today"><div className="text-3xl font-bold">1</div><div>Search Agents Built Today</div></div>
      </div>

      <h2 className="h2 mt-10 mb-3">All-Time Performance</h2>
      <div className="grid md:grid-cols-4 gap-4">
        <div className="metric metric-all"><div className="text-3xl font-bold">87</div><div>Total Jobs Applied</div></div>
        <div className="metric metric-all"><div className="text-3xl font-bold">64</div><div>Total Resumes Optimized</div></div>
        <div className="metric metric-all"><div className="text-3xl font-bold">412</div><div>Total Jobs Found</div></div>
        <div className="metric metric-all"><div className="text-3xl font-bold">5</div><div>Total Search Agents Built</div></div>
      </div>

      <h2 className="h2 mt-10 mb-3">Recent Activity</h2>
      <div className="card">
        <ul className="text-sm text-talSlate space-y-2">
          <li>✅ Application submitted: Project Manager, Acme Corp.</li>
          <li>📝 Resume optimized for Senior Analyst, GlobalTech.</li>
          <li>🔍 25 new jobs found matching your preferences.</li>
        </ul>
        <div className="mt-4">
          <a href="/app/applications"><button className="btn btn-tertiary">View Full History</button></a>
        </div>
      </div>

      <h2 className="h2 mt-10 mb-3">Quick Actions</h2>
      <div className="flex gap-3 flex-wrap">
        <a href="/app/agents"><button className="btn btn-primary">+ Build New Search Agent</button></a>
        <a href="/app/profile"><button className="btn btn-secondary">Refine My Profile</button></a>
        <a href="/app/applications"><button className="btn btn-secondary">Review My Applications</button></a>
      </div>
    </section>
  )
}
