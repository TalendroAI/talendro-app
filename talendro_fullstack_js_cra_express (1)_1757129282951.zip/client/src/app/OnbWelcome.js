export default function Page(){
  return (
    <section>
      <h1 className="h1">Welcome to Talendro™</h1>
      <p className='tagline mt-2'>Precision Matches. Faster Results.</p>
      <div className="mt-6"><p className='body mb-4'>By creating your profile, you unlock our commitment to find more jobs and apply faster than anyone else.</p>
<p className='body mb-4'>We’ll ask for details once so Talendro™ can submit complete, optimized applications at scale.</p></div>
      <div className='mt-6 flex flex-wrap gap-3'><a href='/app/onboarding/step-1'><button className='btn btn-primary mr-3'>Create Your Profile</button></a></div>
    </section>
  )
}
