export default function Page(){
  return (
    <section>
      <h1 className="h1">Employment History</h1>
      <p className="body mt-2">Complete the required fields below.</p>
      <div className="card mt-6">
        <p className="text-talGray">Form fields go here (auto-filled where possible).</p>
      </div>
      <div className="mt-6 flex gap-3">
        <a href="/app/onboarding/review"><button className="btn btn-primary">Continue</button></a>
      </div>
    </section>
  )
}
